# Task 4: CSS Units, Box Model, Fonts

A centered image with a "Click Me" gradient button, built with HTML and CSS only.

## Files
- `index.html` - page structure
- `style.css` - all styles, linked in `index.html`

## Details
- 25% space on the left and right, 10% space on the top and bottom (viewport units)
- `box-sizing: border-box` is used so the page does not scroll
- No flex, no `overflow: hidden`, no relative or absolute position

## How to Run
Open `index.html` in a browser.


